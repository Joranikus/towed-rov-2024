#pragma once

// This template will handle all includes for sensor

#include "pingmessage_ping1D.h"
